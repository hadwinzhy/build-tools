'''
Created on 2011-7-19

@author: zheng
'''

from Common import checkDirs
import subprocess
import glob
import os
import Constant

class Build():
    def __init__(self, project):
        self.checkFile(project)
        self.buildAIDL(project)
        self.buildR(project)
        self.buildJava(project)
        self.buildDex(project)
        self.buildRes(project)
        self.buildApk(project)
    
    def checkFile(self, project):
        checkDirs(project.workspace_path + "gen")
        checkDirs(project.workspace_path + "bin")
        checkDirs(project.workspace_path + "assets")

   
        
    def buildR(self, project):
        command = "aapt package -f -v -M " + project.workspace_path + "AndroidManifest.xml -I " \
                    + project.sdk_path + "android.jar -S " + project.workspace_path + "res/ -m -J " \
                    + project.workspace_path + "gen -A " + project.workspace_path + "assets -F "  \
                    + project.workspace_path + "bin/resources.ap --target-sdk-version 11"
        print "-----------Command is " + command
        subprocess.call(command, shell=True)
        
    def buildAIDL(self, project):
        pattern = '*.aidl'
        for root, dirs, files in os.walk(project.workspace_path + "src"):
            result = glob.glob(os.path.join(root, pattern))
            for f in result:
                path = f;
                f = f.replace("aidl", "java")
                f = f.replace("src", "gen")
                command = "aidl -p" + project.sdk_path + "framework.aidl -I" + project.workspace_path + "src/ -I" \
                            + project.workspace_path + "gen/ " + path + " " + f 
                print "AIDL: " + path 
                print command
                subprocess.call(command, shell=True)

    def buildJava(self, project):
        java_list = ' '
        libs = ""
        pattern = '*.java'
        for root, dirs, files in os.walk(project.workspace_path):
            result = glob.glob(os.path.join(root, pattern))
            for f in result:
                java_list += f + " "
                
        pattern = '*.jar'
        for root, dirs, files in os.walk(project.workspace_path + "libs"):
            result = glob.glob(os.path.join(root, pattern))
            for f in result:
                libs += f + ":"
        
        if project.projectName == Constant.CableBay:
            libs += Constant.google_map_libs
           
        command = "javac -bootclasspath " + project.sdk_path + "android.jar -classpath "\
                     + libs + " -d "\
                     + project.workspace_path + "bin -Xmaxerrs 10 -Xmaxwarns 10" + java_list
        print command 
        subprocess.call(command, shell=True)
        
    def buildDex(self, project):
        command = "dx --verbose --dex --output=" + project.workspace_path + "bin/classes.dex " \
                    + project.workspace_path + "bin/ " + project.workspace_path + "libs"
        print command
        subprocess.call(command, shell=True)
        
    def buildRes(self, project):
        command = "aapt package -f -v -M " + project.workspace_path + "AndroidManifest.xml -S " \
                    + project.workspace_path + "res -A " + project.workspace_path + "assets/ -I " \
                    + project.sdk_path + "android.jar -F " + project.workspace_path + "bin/resources.ap"
        print command
        subprocess.call(command, shell=True)
        
    def buildApk(self, project):
        command = "apkbuilder " + project.workspace_path + "bin/" + project.projectName \
                    + "_unsigned.apk -v -u -z " + project.workspace_path + "bin/resources.ap -f " \
                    + project.workspace_path + "bin/classes.dex -nf " + project.workspace_path + "libs/"
        print command
        subprocess.call(command, shell=True)
        
