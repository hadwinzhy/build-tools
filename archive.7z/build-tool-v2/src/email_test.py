'''
Created on 2011-7-19

@author: zheng
'''
import email
import mimetypes
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
import smtplib
import Constant

class Email():
    authInfo = {}
    fromAdd = ""
    toAdd = ""
    subject = ""
    plainText = ""
    
    def __init__(self):
        self.initData()
        self.sendEmail(self.authInfo, self.fromAdd, self.toAdd, self.subject, self.plainText)
        pass
    
    def initData(self):        
        self.authInfo['server'] = 'smtp.smedio.com.cn'
        self.authInfo['user'] = 'hadwin.zheng'
        self.authInfo['password'] = 'p@ssw1rd'
        self.fromAdd = 'hadwin.zheng@smedio.com.cn'
        self.toAdd = ['hadwinzhy@gmail.com', 'hadwin.zheng@smedio.com.cn', 'fudaner@live.com']
        #self.toAdd ='hadwinzhy@gmail.com fudaner@live.com  hadwin.zheng@smedio.com.cn,'
        #self. = ['mike.wu@smedio.com.cn','felix.long@smedio.com.cn','rejin.ren@smedio.com.cn','jimmy.li@smedio.com.cn','ivy.li@smedio.com.cn','hadwin.zheng@smedio.com.cn','cheney.li@smedio.com.cn']
        self.subject = ' Build Ready'        
        self.plainText = 'Hadwin '
        
        
    def sendEmail(self, authInfo, fromAdd, toAdd, subject, plainText): 
        strFrom = fromAdd
        #strTo = ', '.join(toAdd)
        strTo = toAdd
        server = authInfo.get('server')
        user = authInfo.get('user')
        passwd = authInfo.get('password')

        if not (server and user and passwd) :
                print 'incomplete login info, exit now'
                return

        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = subject
        msgRoot['From'] = strFrom
        msgRoot['To'] = ', '.join(self.toAdd)
        msgRoot.preamble = 'This is a multi-part message in MIME format.'

        # Encapsulate the plain and HTML versions of the message body in an
        # 'alternative' part, so message agents can decide which they want to display.
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)

        msgText = MIMEText(plainText, 'plain', 'utf-8')
        msgAlternative.attach(msgText)

        #msgText = MIMEText(htmlText, 'html', 'utf-8')
        #msgAlternative.attach(msgText)

        #fp = open('test.jpg', 'rb')
        #msgImage = MIMEImage(fp.read())
        #fp.close()
        #msgImage.add_header('Content-ID', '<image1>')
        #msgRoot.attach(msgImage)

        smtp = smtplib.SMTP()
        smtp.set_debuglevel(1)
        smtp.connect(server)
        smtp.login(user, passwd)
        smtp.sendmail(strFrom, strTo, msgRoot.as_string())
        smtp.quit()
        return
       
if __name__ == '__main__':
    Email()
