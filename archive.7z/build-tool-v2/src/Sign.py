'''
Created on 2011-7-19

@author: zheng
'''
import subprocess
import Constant

class Sign():
    
    def __init__(self, project):
        self.finalSign(project)
        pass
    
    
    def finalSign(self, project):
        command = "jarsigner -verbose -keystore " + project.keystore_path + " -signedjar "\
                     + project.workspace_path + "bin/" + project.apk_file_name +" "\
                     + project.workspace_path + "bin/" + project.projectName + "_unsigned.apk " + " " + Constant.alias
                    
        #os.chdir(Constant.tmp_path)
        #command = "jarsigner -verbose -keystore " + project.keystore_path + "-sigfile CERT " \
        #            + "SHI11.apk" + " LISMO"
        print command
        p = subprocess.Popen(command, shell=True, stdin=subprocess.PIPE)
        p.communicate(Constant.password)[0]
        #os.rename("SHI11.apk", "SHI11_signed.apk")
        print "singed complete"
