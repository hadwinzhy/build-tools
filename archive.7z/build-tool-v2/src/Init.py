'''
Created on 2011-7-19

@author: zheng
'''
import Constant
import os

class Init():
    def __init__(self, project):
        self.system_init();
        self.project_init(project);
        

    def system_init(self):
        os.putenv('PATH', "/usr/bin:/bin:" + Constant.bin_path)   
        os.putenv("P4PORT", "192.168.1.5:1960")
        os.putenv("P4USER", "hadwin")
        os.putenv('P4PASSWD', '123456')

    def project_init(self, project):
        if project.projectName == Constant.CableBay:
            project.sdk_path = Constant.sdk_base_path + "android-11/"
            project.keystore_path = Constant.keystore_base_path + "sMedio-sh-android-keystore"
            project.workspace_path = Constant.workspace_base_path + "nemoPlayer/CableBay/" 
