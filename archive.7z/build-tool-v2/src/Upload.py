'''
Created on 2011-7-19

@author: zheng
'''
import smbc
import os
import Constant
from ftplib import FTP

class Upload():
    local_file_name = ''
    def __init__(self, project):
        self.local_file_name = project.workspace_path + "bin/" + project.apk_file_name
        self.uploadSamba(project)
        self.uploadFTP(project)
    
    def uploadSamba(self, project):
        ctx = smbc.Context ()
	project.remote_file_addr = project.folder_name + "/" + project.apk_file_name
	if(project.build_style=="nightly"):
	    ctx.mkdir(Constant.smb_addr + "Nightly_Build/" + project.folder_name, 755)
	    remote_file = ctx.open (Constant.smb_addr + "Nightly_Build/" + project.remote_file_addr, os.O_CREAT | os.O_WRONLY)        
            project.smb_addr_windows=Constant.smb_addr_windows+"Nightly_Build\\"
	elif(project.build_style=="normal"):
	    ctx.mkdir(Constant.smb_addr + "Release_Build/" + project.folder_name, 755)
	    remote_file = ctx.open (Constant.smb_addr + "Release_Build/" + project.remote_file_addr, os.O_CREAT | os.O_WRONLY)
	    project.smb_addr_windows=Constant.smb_addr_windows+"Release_Build\\"
        local_file = open(self.local_file_name)
        remote_file.write(local_file.read())
        
    def uploadFTP(self, project):
        print 'upload ftp'
        ftp = FTP(Constant.ftp_addr)
        ftp.login('cablebay', 'smi0801bew')
        print "login success"
	if(project.build_style=="nightly"):
	    project.ftp_path=Constant.ftp_path + "Nightly_Build/"	
	elif(project.build_style=="normal"):
	    project.ftp_path=Constant.ftp_path
        ftp.mkd(project.ftp_path + project.folder_name)
        ftp.cwd(project.ftp_path + project.folder_name)
        print self.local_file_name
        f = open(self.local_file_name, 'rb')               
        ftp.storbinary('STOR ' + project.apk_file_name, f)
        ftp.retrlines('LIST')
        ftp.quit()
        
if __name__ == '__main__':
    Upload("")
