'''
Created on Apr 19, 2011

@author: zheng
'''

CableBay = "Cablebay"

bin_path = '/local/bin:/opt/android-sdk/tools:/opt/android-sdk/platform-tools/:/opt/java/bin/:'
workspace_base_path = '/local/p4workspace/hadwin-workspace/ANDROID/'
sdk_base_path = '/opt/android-sdk/platforms/'
tmp_path = '/tmp/apk/'
tools_path = '/local/tools/SignatureToolKDDI/'
keystore_base_path = '/local/tools/key/'
password = "android"
alias = "androiddebugkey"
smb_addr = 'smb://192.168.1.176/root_home/CableBay/'

smb_addr_windows = "\\\\192.168.1.176\\root_home\\CableBay\\"
ftp_addr = 'smedio.co-site.jp'
ftp_path = '/release-Build/'
version = "Beta2"
google_map_libs = "/opt/android-sdk/add-ons/addon_google_apis_google_inc_11/libs/maps.jar"
