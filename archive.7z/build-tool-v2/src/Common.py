'''
Created on Apr 20, 2011

@author: zheng
'''
import os
from shutil import rmtree
    
def checkDirs(dir_path):
    if(os.path.exists(dir_path)):
        rmtree(dir_path)
        os.mkdir(dir_path)
    else:
        os.mkdir(dir_path)
        
