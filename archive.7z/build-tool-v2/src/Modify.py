'''
Created on 2011-7-19

@author: zheng
'''
import Constant

class Modify():
	newVersion=""
	def __init__(self , project):
		self.getData(project)
		self.setData(project)

	def getData(self, project):
		fd = open("./config","rw")
		lines = fd.readlines()
		project.versionCode=lines[0][0:-1]
		project.versionName=lines[1][0:-1]
		if(project.build_style=="normal"):
			tmp=int(project.versionCode)
			tmp=tmp+1
			self.newVersion= "\tandroid:versionCode=\"" + str(tmp) + "\""
			fd.write
			print self.newVersion
        

	def setData(self,project):
		fd = open(project.workspace_path+"AndroidManifest.xml","rw")
		lines=fd.readlines()
		lines[3]=self.newVersion+"\n"
		fd.writelines(lines)
		pass



