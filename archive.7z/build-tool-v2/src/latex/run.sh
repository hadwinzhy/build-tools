#!/bin/sh
pdflatex main.tex
acroread main.pdf
