'''
Created on 2011-7-19

@author: zheng
'''
import subprocess
import Constant
import re
import time
from Common import checkDirs

class Download():
    p4RemotePath = ''
    def __init__(self , project):
        if project.projectName == Constant.CableBay:
            self.p4RemotePath = '//depot/ANDROID/nemoPlayer/CableBay/...'
        #remove all project files
        checkDirs(project.workspace_path);
        self.p4_forceDownload(project.projectName)
        self.getLatestCommit(project)
        pass
    
    def p4_forceDownload(self, projectName):
	    print 'p4 sync -f ' + self.p4RemotePath + '#head'
            subprocess.call('p4 sync -f ' + self.p4RemotePath + '#head', shell=True)
            
    def getLatestCommit(self, project):
        p = subprocess.Popen('p4 changes -s submitted  -m 1 ' + self.p4RemotePath, shell=True \
                             , stdout=subprocess.PIPE)
        output = p.communicate(subprocess.PIPE)[0]
        pattern = re.compile(r'\D+(\d+)\D+')
        match = pattern.match(output)
        if match:   
            project.lastestCommit = match.group(1)
            today = time.strftime("%Y_%m_%d", time.localtime())
            project.folder_name = project.projectName + "_" + Constant.version + "_" + project.lastestCommit \
                + "_" + today
            
